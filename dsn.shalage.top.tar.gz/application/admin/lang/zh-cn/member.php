<?php

return [
    'Id'         => 'ID',
    'Openid'     => 'openid',
    'Nickname'   => '昵称',
    'Gender'     => '性别',
    'Gender 0'   => '保密',
    'Gender 1'   => '男',
    'Gender 2'   => '女',
    'Phone'      => '手机号',
    'Avatar'     => '头像',
    'Country'    => '国家',
    'Province'   => '省份',
    'Citys'      => '城市',
    'Money'      => '余额',
    'Status'     => '状态',
    'Status 1'   => '正常',
    'Status 0'   => '禁用',
    'Createtime' => '注册时间',
    'Prevtime'   => '上次登录时间',
    'Logintime'  => '登录时间',
    'Jointime'   => '加入时间',
    'Topid'      => '父级ID',
    'Is_zx'      => '是否查询征信',
    'Is_zx 0'    => '否',
    'Is_zx 1'    => '是'
];
