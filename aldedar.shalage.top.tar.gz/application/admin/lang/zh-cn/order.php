<?php

return [
    'Id'              => 'ID',
    'Member_id'       => '会员ID',
    'Name'            => '姓名',
    'Idcard'          => '身份证号',
    'Mobile'          => '手机号',
    'Price'           => '付款价格',
    'Status'          => '状态',
    'Status 0'        => '未付款',
    'Status 1'        => '付款成功',
    'Order_num'       => '订单号',
    'Createtime'      => '下单时间',
    'Type'            => '类型',
    'Type 0'          => '信用查询',
    'Type 1'          => '银行卡查询',
    'Member.nickname' => '昵称',
    'Member.avatar'   => '头像'
];
