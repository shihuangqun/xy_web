<?php

return [
    'Id'         => 'ID',
    'Image'      => '图片',
    'Createtime' => '添加时间'
];
