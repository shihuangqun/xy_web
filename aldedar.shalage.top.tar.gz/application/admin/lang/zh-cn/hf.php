<?php

return [
    'Title' => '备注',
    'Price' => '价格'
];
