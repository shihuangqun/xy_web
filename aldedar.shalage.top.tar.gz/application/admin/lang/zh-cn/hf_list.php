<?php

return [
    'Member_id'       => '会员ID',
    'Amount'          => '充值金额',
    'Price'           => '付款金额',
    'Status'          => '支付状态',
    'Status 0'        => '未支付',
    'Status 1'        => '支付成功',
    'Mobile'          => '手机号',
    'Order_num'       => '订单号',
    'Createtime'      => '充值时间',
    'Re_status'       => '充值状态',
    'Re_status 0'     => '未成功',
    'Re_status 1'     => '成功',
    'Member.nickname' => '昵称',
    'Member.avatar'   => '头像'
];
