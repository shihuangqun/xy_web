<?php

return [
    'name'        => '配置名称',
    'value'       => '配置值',
    'Json key'    => '键',
    'Json value'  => '值',
    'Json editor' => 'JSON编辑器',
    'Insert link' => '插入链接',
    'createtime'  => '创建时间',
    'updatetime'  => '更新时间'
];
