<?php
/**
 * 返回类
 */

class ResultResp {
    /**
     * 返回的错误码
     **/
    public $code;

    /**
     * 返回的错误信息
     **/
    public $message;
}